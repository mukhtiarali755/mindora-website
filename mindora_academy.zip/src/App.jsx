import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function MindoraAcademy() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold text-blue-700">Mindora Academy</h1>
        <p className="text-xl mt-2">Empowering students in English and Maths</p>
      </header>

      <main className="grid gap-8 grid-cols-1 md:grid-cols-2">
        <Card className="rounded-2xl shadow-md p-4">
          <CardContent>
            <h2 className="text-2xl font-semibold mb-4">English Program</h2>
            <p className="mb-4">
              Our English courses focus on grammar, vocabulary, reading comprehension,
              and writing skills. We help students from beginner to advanced levels.
            </p>
            <Button className="bg-blue-600 hover:bg-blue-700">Learn More</Button>
          </CardContent>
        </Card>

        <Card className="rounded-2xl shadow-md p-4">
          <CardContent>
            <h2 className="text-2xl font-semibold mb-4">Maths Program</h2>
            <p className="mb-4">
              Our Maths curriculum covers arithmetic, algebra, geometry, and problem-solving
              techniques. Designed to make learning fun and effective.
            </p>
            <Button className="bg-green-600 hover:bg-green-700">Learn More</Button>
          </CardContent>
        </Card>
      </main>

      <section className="text-center mt-16">
        <h2 className="text-3xl font-bold mb-4">Why Choose Mindora Academy?</h2>
        <ul className="text-left mx-auto max-w-xl space-y-2">
          <li>✓ Expert tutors with years of experience</li>
          <li>✓ Interactive and personalized learning</li>
          <li>✓ Affordable and flexible programs</li>
          <li>✓ Supportive learning environment</li>
        </ul>
      </section>

      <footer className="mt-16 text-center text-sm text-gray-500">
        &copy; {new Date().getFullYear()} Mindora Academy. All rights reserved.
      </footer>
    </div>
  );
}
